
<?php 
header('Location: public/');
