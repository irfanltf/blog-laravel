

<?php $__env->startSection('container'); ?>
<h1>Halaman About</h1>
<h1><?php echo e($nama); ?></h1>
<h1><?php echo e($email); ?></h1>

<img src="img/<?php echo e($image); ?>" alt="" width="200" class="img-thumbnail rounded-circle">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app-laravel8\resources\views/about.blade.php ENDPATH**/ ?>